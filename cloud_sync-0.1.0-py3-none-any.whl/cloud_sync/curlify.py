"""
Wrapper around Curlify to make it transparent
in production, where it's not installed
"""

try:
    from curlify2 import Curlify as _real_Curlify
except ImportError:
    _real_Curlify = None

import httpx


# noinspection PyMethodMayBeStatic
class _FakeCurlify:
    def __init__(self, request: httpx.Request):
        self.request = request

    def to_curl(self) -> str:
        return "curlify not installed, cannot generate cURL command."


Curlify = _real_Curlify if _real_Curlify is not None else _FakeCurlify


def record_interaction_to_file(response: httpx.Response, filepath: str) -> None:
    with open(filepath, "a") as f:
        f.write("\n\n")
        f.write(Curlify(response.request).to_curl())
        f.write("\n\n")
        f.write("Response:\n")
        f.write("Status code: " + str(response.status_code) + "\n")
        f.write(
            "Headers: "
            + "\n".join(k + ": " + v for k, v in response.request.headers.items())
            + "\n"
        )
        f.write(response.text)
